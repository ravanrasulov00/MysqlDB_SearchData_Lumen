<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
class LiveSearch extends Controller{


     function getdataa(Request $request)
    {


        $query = $request->get('query');
        $data = DB::table('workersdb')
            ->where('name', 'like', '%' . $query . '%')
            ->orWhere('surname', 'like', '%' . $query . '%')
            ->orWhere('fathersname', 'like', '%' . $query . '%')
            ->orWhere('position', 'like', '%' . $query . '%')
            ->orWhere('department', 'like', '%' . $query . '%')
            ->orWhere('mobilenumber', 'like', '%' . $query . '%')
            ->orWhere('worknumber', 'like', '%' . $query . '%')
            ->get();


        return response($data);

    }




}
